import fs from 'fs';
import path from 'path';
import inquirer from 'inquirer';
import chalk from 'chalk';
import { txt2img } from './puter.js';

export async function generateImage() {
  const { prompt } = await inquirer.prompt([
    {
      type: 'input',
      name: 'prompt',
      message: chalk.yellow('Describe the image you want:'),
      validate: (v) => (v && v.trim().length > 2 ? true : 'Please enter a prompt.'),
    },
  ]);

  console.log(chalk.gray('Generating image with Puter AI...'));
  const img = await txt2img(prompt);

  const outDir = path.join(process.cwd(), 'images');
  fs.mkdirSync(outDir, { recursive: true });
  const file = path.join(outDir, `sonic-${Date.now()}.png`);

  // puter.ai.txt2img may return a Blob-like object (Node) or an <img>/URL string
  if (img && typeof img.arrayBuffer === 'function') {
    const buf = Buffer.from(await img.arrayBuffer());
    fs.writeFileSync(file, buf);
    console.log(chalk.green(`Image saved: ${file}`));
  } else if (typeof img === 'string') {
    if (img.startsWith('http')) {
      const res = await fetch(img);
      const buf = Buffer.from(await res.arrayBuffer());
      fs.writeFileSync(file, buf);
      console.log(chalk.green(`Image saved: ${file}`));
      console.log(chalk.yellow('URL: ' + img));
    } else if (img.startsWith('data:')) {
      const b64 = img.split(',')[1];
      fs.writeFileSync(file, Buffer.from(b64, 'base64'));
      console.log(chalk.green(`Image saved: ${file}`));
    } else {
      console.log(chalk.yellow('Result: ' + img));
    }
  } else if (img && img.src) {
    console.log(chalk.yellow('Image URL: ' + img.src));
  } else {
    console.log(chalk.red('Could not read the generated image.'));
  }
}

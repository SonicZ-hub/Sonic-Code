import fs from 'fs';
import path from 'path';
import inquirer from 'inquirer';
import chalk from 'chalk';
import { aiChat } from './ai.js';
import { SYSTEM_PROMPT, buildPrompt } from './prompts.js';
import { deploySite } from './puter.js';

function parseFiles(text) {
  const files = {};
  const re = /===FILE:\s*([^\n=]+?)\s*===\n([\s\S]*?)===END FILE===/g;
  let m;
  while ((m = re.exec(text)) !== null) {
    const filePath = m[1].trim().replace(/^\/+/, '');
    files[filePath] = m[2].replace(/^\n+/, '').replace(/\s+$/, '') + '\n';
  }
  return files;
}

function saveLocal(projectDir, files) {
  fs.mkdirSync(projectDir, { recursive: true });
  for (const [filePath, content] of Object.entries(files)) {
    const full = path.join(projectDir, filePath);
    fs.mkdirSync(path.dirname(full), { recursive: true });
    fs.writeFileSync(full, content, 'utf8');
  }
}

function spinner(text) {
  const frames = ['|', '/', '-', '\\'];
  let i = 0;
  process.stdout.write('  ');
  const t = setInterval(() => {
    process.stdout.write(`\r  ${chalk.yellow(frames[i++ % frames.length])} ${text}`);
  }, 120);
  return () => {
    clearInterval(t);
    process.stdout.write('\r' + ' '.repeat(text.length + 8) + '\r');
  };
}

export async function buildFullStack(kind) {
  const label = kind === 'app' ? 'Full Stack App' : 'Full Stack Website';

  const { description } = await inquirer.prompt([
    {
      type: 'input',
      name: 'description',
      message: chalk.yellow(`Describe the ${label.toLowerCase()} you want:`),
      validate: (v) => (v && v.trim().length > 3 ? true : 'Please describe your project.'),
    },
  ]);

  const { name } = await inquirer.prompt([
    {
      type: 'input',
      name: 'name',
      message: 'Project name (folder/subdomain):',
      default: 'my-project',
      validate: (v) => (/^[a-z0-9-]+$/i.test(v.trim()) ? true : 'Use letters, numbers and dashes only.'),
    },
  ]);

  let stop = spinner(`AI is building your ${label.toLowerCase()}...`);
  let raw;
  try {
    raw = await aiChat([
      { role: 'system', content: SYSTEM_PROMPT },
      { role: 'user', content: buildPrompt(kind, description) },
    ]);
  } finally {
    stop();
  }

  const files = parseFiles(raw);
  if (Object.keys(files).length === 0) {
    console.log(chalk.red('The AI response had no files. Try again with a clearer description.'));
    return;
  }
  if (!files['index.html']) {
    files['index.html'] = '<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>App</title></head><body><script src="js/backend.js"></script><script src="js/app.js"></script></body></html>\n';
  }

  const projectDir = path.join(process.cwd(), 'projects', name);
  saveLocal(projectDir, files);
  console.log(chalk.green(`Saved ${Object.keys(files).length} files to ./projects/${name}/`));

  stop = spinner('Deploying to Puter hosting...');
  try {
    const site = await deploySite(name, files);
    stop();
    console.log('');
    console.log(chalk.bgYellow.black.bold('  PREVIEW LINK  '));
    console.log(chalk.yellow.bold('  ' + site.url));
    console.log('');
  } catch (err) {
    stop();
    console.log(chalk.red('Deploy failed: ' + (err && err.message ? err.message : err)));
    console.log(chalk.gray('Your files are still saved locally in ./projects/' + name + '/'));
  }
}

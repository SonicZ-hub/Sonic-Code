import fs from 'fs';
import path from 'path';
import inquirer from 'inquirer';
import chalk from 'chalk';

const ENV_PATH = path.join(process.cwd(), '.env');

function readEnv() {
  const out = {};
  if (fs.existsSync(ENV_PATH)) {
    for (const line of fs.readFileSync(ENV_PATH, 'utf8').split('\n')) {
      const m = line.match(/^([A-Z0-9_]+)=(.*)$/);
      if (m) out[m[1]] = m[2].trim();
    }
  }
  return out;
}

function writeEnv(vars) {
  const body = Object.entries(vars)
    .map(([k, v]) => `${k}=${v}`)
    .join('\n');
  fs.writeFileSync(ENV_PATH, body + '\n', 'utf8');
}

export async function ensureConfig() {
  const existing = { ...readEnv() };

  const needsAI = !process.env.OPENROUTER_API_KEY && !process.env.NVIDIA_API_KEY && !existing.OPENROUTER_API_KEY && !existing.NVIDIA_API_KEY;

  if (needsAI) {
    console.log(chalk.yellow('No AI API key found. Let us set one up.'));
    const { provider } = await inquirer.prompt([
      {
        type: 'list',
        name: 'provider',
        message: 'Which AI provider do you want to use?',
        choices: ['OpenRouter', 'NVIDIA'],
      },
    ]);
    const { key } = await inquirer.prompt([
      { type: 'password', name: 'key', message: `Paste your ${provider} API key:`, mask: '*' },
    ]);
    if (provider === 'OpenRouter') existing.OPENROUTER_API_KEY = key;
    else existing.NVIDIA_API_KEY = key;
    existing.AI_PROVIDER = provider === 'OpenRouter' ? 'openrouter' : 'nvidia';
  } else {
    existing.AI_PROVIDER =
      process.env.AI_PROVIDER ||
      existing.AI_PROVIDER ||
      (existing.OPENROUTER_API_KEY || process.env.OPENROUTER_API_KEY ? 'openrouter' : 'nvidia');
  }

  if (!process.env.PUTER_AUTH_TOKEN && !existing.PUTER_AUTH_TOKEN) {
    const { token } = await inquirer.prompt([
      {
        type: 'password',
        name: 'token',
        message: 'Paste your Puter auth token (from puter.com/dashboard > Create token) for preview links & image generation:',
        mask: '*',
      },
    ]);
    existing.PUTER_AUTH_TOKEN = token;
  }

  writeEnv(existing);

  for (const [k, v] of Object.entries(existing)) process.env[k] = v;

  console.log(chalk.green('Config saved to .env\n'));
}

export function getConfig() {
  return {
    provider: (process.env.AI_PROVIDER || 'openrouter').toLowerCase(),
    openrouterKey: process.env.OPENROUTER_API_KEY || '',
    nvidiaKey: process.env.NVIDIA_API_KEY || '',
    puterToken: process.env.PUTER_AUTH_TOKEN || '',
  };
}

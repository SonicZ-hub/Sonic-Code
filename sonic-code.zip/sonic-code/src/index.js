import dotenv from 'dotenv';
import { printBanner } from './banner.js';
import { showMainMenu } from './menu.js';
import { ensureConfig } from './config.js';

dotenv.config();

export async function main() {
  await printBanner();
  await ensureConfig();
  await showMainMenu();
}

import inquirer from 'inquirer';
import chalk from 'chalk';
import { aiChat } from './ai.js';

export async function chatWithAI() {
  console.log(chalk.yellow.bold('\nChat with AI (type "exit" to go back)\n'));
  const history = [
    { role: 'system', content: 'You are Sonic Code AI assistant. Be helpful, concise and friendly.' },
  ];

  while (true) {
    const { msg } = await inquirer.prompt([
      { type: 'input', name: 'msg', message: chalk.cyan('you:') },
    ]);

    if (!msg || msg.trim().toLowerCase() === 'exit') {
      console.log('');
      return;
    }

    history.push({ role: 'user', content: msg });
    try {
      const reply = await aiChat(history, { temperature: 0.7 });
      history.push({ role: 'assistant', content: reply });
      console.log(chalk.yellow('\nsonic: ') + reply + '\n');
    } catch (err) {
      console.log(chalk.red('Error: ' + (err && err.message ? err.message : err)));
    }
  }
}

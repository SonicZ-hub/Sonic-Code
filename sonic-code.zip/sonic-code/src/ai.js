import { getConfig } from './config.js';

const OPENROUTER_URL = 'https://openrouter.ai/api/v1/chat/completions';
const NVIDIA_URL = 'https://integrate.api.nvidia.com/v1/chat/completions';

const DEFAULT_MODELS = {
  openrouter: 'openrouter/auto',
  nvidia: 'nvidia/llama-3.1-nemotron-70b-instruct',
};

export async function aiChat(messages, options = {}) {
  const cfg = getConfig();

  let url, key, model;
  if (cfg.provider === 'nvidia') {
    url = NVIDIA_URL;
    key = cfg.nvidiaKey;
    model = options.model || process.env.NVIDIA_MODEL || DEFAULT_MODELS.nvidia;
  } else {
    url = OPENROUTER_URL;
    key = cfg.openrouterKey;
    model = options.model || process.env.OPENROUTER_MODEL || DEFAULT_MODELS.openrouter;
  }

  if (!key) throw new Error(`No API key configured for provider "${cfg.provider}". Check your .env file.`);

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${key}`,
      'Content-Type': 'application/json',
      ...(cfg.provider === 'openrouter'
        ? { 'HTTP-Referer': 'https://github.com/sonic-code', 'X-Title': 'Sonic Code' }
        : {}),
    },
    body: JSON.stringify({
      model,
      messages,
      temperature: options.temperature ?? 0.4,
      max_tokens: options.maxTokens ?? 8192,
      stream: false,
    }),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`AI request failed (${res.status}): ${text.slice(0, 400)}`);
  }

  const data = await res.json();
  const content = data && data.choices && data.choices[0] && data.choices[0].message
    ? data.choices[0].message.content
    : '';
  if (!content) throw new Error('AI returned an empty response.');
  return content;
}

export const SYSTEM_PROMPT = `You are Sonic Code, an expert full-stack code generator.

RULES (follow exactly):
1. Output ONLY code files. No explanation, no commentary, no markdown prose.
2. Wrap EVERY file in this exact format:

===FILE: path/to/file.ext===
<file content here>
===END FILE===

3. The project must be a STATIC front-end app that runs by opening index.html (Puter hosting serves static files).
4. Simulate the backend INSIDE the front-end: a "backend.js" module that acts as a fake REST API/data layer using localStorage, plus any database logic written as JS. This makes the app fully functional with login, CRUD, etc., with zero servers.
5. Always include at minimum: index.html, css/style.css, js/backend.js, js/app.js
6. Make the UI beautiful: modern, responsive, mobile-first, dark-accented design, smooth CSS.
7. Do NOT use external build steps. CDN links (Tailwind, fonts, icons) are allowed.
8. Code must be complete and runnable. No placeholders like "// TODO".`;

export function buildPrompt(kind, description) {
  const kindText =
    kind === 'app'
      ? 'a full-stack mobile-style web APP (app-like UI, bottom nav, screens)'
      : 'a full-stack WEBSITE (landing page + working app sections)';

  return `Build ${kindText} based on this description:

"${description}"

Requirements:
- Front-end: polished responsive HTML/CSS/JS.
- Backend: simulated in js/backend.js using a Backend class with localStorage persistence (users, auth, data CRUD) so the app genuinely works.
- Wire everything together so every button works.
- Remember: output files ONLY, using the ===FILE: ...=== / ===END FILE=== format.`;
}

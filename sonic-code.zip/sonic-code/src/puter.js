import { puter } from '@heyputer/puter.js';
import { getConfig } from './config.js';

let authed = false;

export function getPuter() {
  if (!authed) {
    const { puterToken } = getConfig();
    if (!puterToken) {
      throw new Error('PUTER_AUTH_TOKEN is missing. Add it to your .env (get one at puter.com/dashboard > Create token).');
    }
    puter.setAuthToken(puterToken);
    authed = true;
  }
  return puter;
}

export async function deploySite(dirName, files) {
  const p = getPuter();

  const cleanDir = dirName.replace(/[^a-z0-9-]/gi, '-').toLowerCase();

  for (const [filePath, content] of Object.entries(files)) {
    const fullPath = `${cleanDir}/${filePath}`;
    await p.fs.write(fullPath, content, { createMissingParents: true });
  }

  const subdomainName = `sonic-${cleanDir}-${Math.random().toString(36).slice(2, 8)}`;
  const site = await p.hosting.create(subdomainName, cleanDir);

  return {
    subdomain: site.subdomain || subdomainName,
    url: `https://${site.subdomain || subdomainName}.puter.site`,
  };
}

export async function txt2img(prompt) {
  const p = getPuter();
  const img = await p.ai.txt2img(prompt);
  return img;
}

import inquirer from 'inquirer';
import chalk from 'chalk';
import { buildFullStack } from './build.js';
import { chatWithAI } from './chat.js';
import { generateImage } from './imagegen.js';

export async function showMainMenu() {
  while (true) {
    const { choice } = await inquirer.prompt([
      {
        type: 'list',
        name: 'choice',
        message: chalk.yellow.bold('SONIC CODE - what do you want to do?'),
        choices: [
          { name: '  Full Stack Website', value: 'website' },
          { name: '  Full Stack App', value: 'app' },
          { name: '  Chat with AI', value: 'chat' },
          { name: '  Photo Generator', value: 'image' },
          new inquirer.Separator(),
          { name: 'Exit', value: 'exit' },
        ],
      },
    ]);

    try {
      if (choice === 'website') await buildFullStack('website');
      else if (choice === 'app') await buildFullStack('app');
      else if (choice === 'chat') await chatWithAI();
      else if (choice === 'image') await generateImage();
      else if (choice === 'exit') {
        console.log(chalk.yellow.bold('\nSONIC CODE - happy coding!\n'));
        process.exit(0);
      }
    } catch (err) {
      console.log(chalk.red('\nSomething went wrong: ' + (err && err.message ? err.message : err) + '\n'));
    }
  }
}

import chalk from 'chalk';
import figlet from 'figlet';

export async function printBanner() {
  const art = figlet.textSync('SONIC CODE', {
    font: 'Standard',
    horizontalLayout: 'default',
  });

  const line = '='.repeat(52);
  console.log(chalk.bgYellow.black(' ' + line + ' '));
  console.log(chalk.bgYellow.black.bold('        choice of mobile coders        '));
  console.log(chalk.bgYellow.black(' ' + line + ' '));
  console.log(chalk.bgYellow.black.bold(art));
  console.log(chalk.bgYellow.black(' ' + line + ' '));
  console.log('');
}
